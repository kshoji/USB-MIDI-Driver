package jp.kshoji.driver.midi.device;

import static android.content.Context.RECEIVER_NOT_EXPORTED;
import static jp.kshoji.driver.midi.util.Constants.TAG;

import android.annotation.SuppressLint;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.hardware.usb.UsbDevice;
import android.hardware.usb.UsbDeviceConnection;
import android.hardware.usb.UsbInterface;
import android.hardware.usb.UsbManager;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;

import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Queue;
import java.util.Set;

import jp.kshoji.driver.midi.listener.OnMidiDeviceAttachedListener;
import jp.kshoji.driver.midi.listener.OnMidiDeviceDetachedListener;
import jp.kshoji.driver.midi.util.UsbMidiDeviceUtils;
import jp.kshoji.driver.usb.util.DeviceFilter;

/**
 * Detects USB MIDI Device Connected
 * stop() method must be called when the application will be destroyed.
 * 
 * @author K.Shoji
 */
public final class MidiDeviceConnectionWatcher {
	private final MidiDeviceConnectionWatchThread thread;
	final Context context;
    final UsbManager usbManager;

    final Handler deviceDetachedHandler;
    final OnMidiDeviceDetachedListener deviceDetachedListener;

    volatile boolean isGranting;
    volatile UsbDevice grantingDevice;
    final Queue<UsbDevice> deviceGrantQueue = new LinkedList<>();
    final HashSet<UsbDevice> grantedDevices = new HashSet<>();

    Map<UsbDevice, UsbDeviceConnection> deviceConnections = new HashMap<>();
    Map<UsbDevice, Set<MidiInputDevice>> midiInputDevices = new HashMap<>();
    Map<UsbDevice, Set<MidiOutputDevice>> midiOutputDevices = new HashMap<>();
    
    // Track registered receivers for proper cleanup
    private final Set<UsbMidiGrantedReceiver> registeredReceivers = new HashSet<>();

    /**
	 * Constructor
	 *
     * @param context the Context
	 * @param usbManager the UsbManager
     * @param deviceAttachedListener the OnMidiDeviceAttachedListener
     */
	public MidiDeviceConnectionWatcher(@NonNull Context context, @NonNull UsbManager usbManager, @NonNull OnMidiDeviceAttachedListener deviceAttachedListener, @NonNull final OnMidiDeviceDetachedListener deviceDetachedListener) {
		// Use ApplicationContext to avoid memory leaks and lifecycle issues
		this.context = context.getApplicationContext();
        this.usbManager = usbManager;
		isGranting = false;
        grantingDevice = null;
        this.deviceDetachedListener = deviceDetachedListener;

        deviceDetachedHandler = new Handler(Looper.getMainLooper());

		thread = new MidiDeviceConnectionWatchThread(usbManager, deviceAttachedListener, deviceDetachedHandler);
        thread.setName("MidiDeviceConnectionWatchThread");
		thread.start();
	}

    /**
     * Notify the specified device has been detached
     *
     * @param detachedDevice the USB MIDI device
     */
    private void onDeviceDetached(@NonNull UsbDevice detachedDevice) {
        deviceDetachedListener.onDeviceDetached(detachedDevice);

        // Stop input device's thread.
        Set<MidiInputDevice> inputDevices = midiInputDevices.get(detachedDevice);
        if (inputDevices != null && inputDevices.size() > 0) {
            for (MidiInputDevice inputDevice : inputDevices) {
                if (inputDevice != null) {
                    inputDevice.stop();

                    deviceDetachedListener.onMidiInputDeviceDetached(inputDevice);
                }
            }
            midiInputDevices.remove(detachedDevice);
        }

        Set<MidiOutputDevice> outputDevices = midiOutputDevices.get(detachedDevice);
        if (outputDevices != null) {
            for (MidiOutputDevice outputDevice : outputDevices) {
                if (outputDevice != null) {
                    outputDevice.stop();

                    deviceDetachedListener.onMidiOutputDeviceDetached(outputDevice);
                }
            }
            midiOutputDevices.remove(detachedDevice);
        }

        // Close the device connection after all devices have been stopped
        // This ensures that interfaces are released before closing the connection
        UsbDeviceConnection deviceConnection = deviceConnections.get(detachedDevice);
        if (deviceConnection != null) {
            deviceConnection.close();
            deviceConnections.remove(detachedDevice);
        }
    }

    /**
     * Checks the connected USB MIDI devices
     */
    public void checkConnectedDevicesImmediately() {
		thread.checkConnectedDevices();
	}
	
	/**
	 * Stops the watching thread
	 * <p>
	 * Note: This method should not be called from the main thread to avoid ANR.
	 * The device attached / detached events will be noticed until the thread completely stops.
	 * </p>
	 */
	public void stop() {
		thread.stopFlag = true;
        thread.interrupt();

		// Unregister all receivers on the main thread
		deviceDetachedHandler.post(() -> {
			synchronized (registeredReceivers) {
				for (UsbMidiGrantedReceiver receiver : registeredReceivers) {
					try {
						context.unregisterReceiver(receiver);
					} catch (IllegalArgumentException e) {
						// Receiver may have been already unregistered
						Log.d(TAG, "Receiver already unregistered", e);
					}
				}
				registeredReceivers.clear();
			}
		});

		// Wait for thread to stop with timeout to avoid blocking indefinitely
		// Use a timeout to prevent blocking the calling thread for too long
		long timeout = System.currentTimeMillis() + 2000; // 2 second timeout
		while (thread.isAlive() && System.currentTimeMillis() < timeout) {
			try {
				Thread.sleep(100);
			} catch (InterruptedException e) {
				// Restore interrupted status
				Thread.currentThread().interrupt();
				break;
			}
		}
		
		if (thread.isAlive()) {
			Log.w(TAG, "Thread did not stop within timeout period");
		}
	}
	
	/**
	 * Broadcast receiver for MIDI device connection granted
	 * 
	 * @author K.Shoji
	 */
	private final class UsbMidiGrantedReceiver extends BroadcastReceiver {
		private static final String USB_PERMISSION_GRANTED_ACTION = "jp.kshoji.driver.midi.USB_PERMISSION_GRANTED_ACTION";
		
		private final UsbDevice device;
		private final OnMidiDeviceAttachedListener deviceAttachedListener;
		
		/**
		 * @param device the UsbDevice
		 * @param deviceAttachedListener the OnMidiDeviceAttachedListener
		 */
		public UsbMidiGrantedReceiver(@NonNull UsbDevice device, @NonNull OnMidiDeviceAttachedListener deviceAttachedListener) {
			this.device = device;
			this.deviceAttachedListener = deviceAttachedListener;
		}
		
		@Override
		public void onReceive(Context receiverContext, Intent intent) {
			String action = intent.getAction();
			if (USB_PERMISSION_GRANTED_ACTION.equals(action)) {
				boolean granted = intent.getBooleanExtra(UsbManager.EXTRA_PERMISSION_GRANTED, false);
				if (granted) {
                    grantedDevices.add(device);
                    deviceAttachedListener.onDeviceAttached(device);

                    UsbDeviceConnection deviceConnection = usbManager.openDevice(device);
                    if (deviceConnection == null) {
                        // Unregister receiver on main thread after processing
                        deviceDetachedHandler.post(() -> unregisterReceiverSafely(this));
                        return;
                    }

                    deviceConnections.put(device, deviceConnection);

                    List<DeviceFilter> deviceFilters = DeviceFilter.getDeviceFilters(context.getApplicationContext());

                    Set<MidiInputDevice> foundInputDevices = UsbMidiDeviceUtils.findMidiInputDevices(device, deviceConnection, deviceFilters);
                    for (MidiInputDevice midiInputDevice : foundInputDevices) {
                        try {
                            Set<MidiInputDevice> inputDevices = midiInputDevices.get(device);
                            if (inputDevices == null) {
                                inputDevices = new HashSet<>();
                            }
                            inputDevices.add(midiInputDevice);
                            midiInputDevices.put(device, inputDevices);

                            deviceAttachedListener.onMidiInputDeviceAttached(midiInputDevice);
                        } catch (IllegalArgumentException iae) {
                            Log.d(TAG, "This device didn't have any input endpoints.", iae);
                        }
                    }

                    Set<MidiOutputDevice> foundOutputDevices = UsbMidiDeviceUtils.findMidiOutputDevices(device, deviceConnection, deviceFilters);
                    for (MidiOutputDevice midiOutputDevice : foundOutputDevices) {
                        try {
                            Set<MidiOutputDevice> outputDevices = midiOutputDevices.get(device);
                            if (outputDevices == null) {
                                outputDevices = new HashSet<>();
                            }
                            outputDevices.add(midiOutputDevice);
                            midiOutputDevices.put(device, outputDevices);

                            deviceAttachedListener.onMidiOutputDeviceAttached(midiOutputDevice);
                        } catch (IllegalArgumentException iae) {
                            Log.d(TAG, "This device didn't have any output endpoints.", iae);
                        }
                    }

                    Log.d(TAG, "Device " + device.getDeviceName() + " has been attached.");
				}

                // Reset the 'isGranting' to false
                isGranting = false;
                grantingDevice = null;
                
                // Unregister receiver on main thread after processing
                // Do not call unregisterReceiver directly from onReceive to avoid thread safety issues
                deviceDetachedHandler.post(() -> unregisterReceiverSafely(this));
			}
		}
		
		/**
		 * Safely unregister a receiver
		 * @param receiver the receiver to unregister
		 */
		private void unregisterReceiverSafely(UsbMidiGrantedReceiver receiver) {
			synchronized (registeredReceivers) {
				if (registeredReceivers.contains(receiver)) {
					try {
						context.unregisterReceiver(receiver);
						registeredReceivers.remove(receiver);
					} catch (IllegalArgumentException e) {
						// Receiver may have been already unregistered
						Log.d(TAG, "Receiver already unregistered", e);
						registeredReceivers.remove(receiver);
					}
				}
			}
		}
	}
	
	/**
	 * USB Device polling thread
	 * 
	 * @author K.Shoji
	 */
	private final class MidiDeviceConnectionWatchThread extends Thread {
		private final UsbManager usbManager;
		private OnMidiDeviceAttachedListener deviceAttachedListener;
		private Handler deviceDetachedHandler;
		private Set<UsbDevice> connectedDevices;
		boolean stopFlag;
		private List<DeviceFilter> deviceFilters;
		private String packageName;

		/**
		 * Constructor
         *
		 * @param usbManager the UsbManager
		 * @param deviceAttachedListener the OnMidiDeviceAttachedListener
		 * @param deviceDetachedHandler the OnMidiDeviceDetachedListener
		 */
		MidiDeviceConnectionWatchThread(@NonNull UsbManager usbManager, @NonNull OnMidiDeviceAttachedListener deviceAttachedListener, @NonNull Handler deviceDetachedHandler) {
			this.usbManager = usbManager;
			this.deviceAttachedListener = deviceAttachedListener;
			this.deviceDetachedHandler = deviceDetachedHandler;
			this.packageName = context.getPackageName();
			connectedDevices = new HashSet<>();
			stopFlag = false;
			deviceFilters = DeviceFilter.getDeviceFilters(context);
		}

		@SuppressLint("UnspecifiedRegisterReceiverFlag")
		@Override
		public void run() {
			super.run();
			
			while (stopFlag == false) {
				checkConnectedDevices();
				
				synchronized (deviceGrantQueue) {
					if (!deviceGrantQueue.isEmpty() && !isGranting) {
						isGranting = true;
						grantingDevice = deviceGrantQueue.remove();

						Intent intent = new Intent(UsbMidiGrantedReceiver.USB_PERMISSION_GRANTED_ACTION);
						intent.setPackage(packageName); // Make intent explicit

						// Android 12 (API 31) and above require FLAG_MUTABLE or FLAG_IMMUTABLE
						int intentFlags;
						if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
							// Android 12+ requires explicit mutability flag
							intentFlags = PendingIntent.FLAG_MUTABLE;
						} else if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
							// Android 6.0+ supports FLAG_MUTABLE but it's not required
							intentFlags = PendingIntent.FLAG_UPDATE_CURRENT;
						} else {
							intentFlags = PendingIntent.FLAG_UPDATE_CURRENT;
						}

						PendingIntent permissionIntent = PendingIntent.getBroadcast(
							context, 0, intent, intentFlags
						);

						UsbMidiGrantedReceiver receiver = new UsbMidiGrantedReceiver(grantingDevice, deviceAttachedListener);
						IntentFilter filter = new IntentFilter(UsbMidiGrantedReceiver.USB_PERMISSION_GRANTED_ACTION);

						// Register receiver and track it for proper cleanup
						if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
							context.registerReceiver(receiver, filter, RECEIVER_NOT_EXPORTED);
						} else {
							// @SuppressLint("UnspecifiedRegisterReceiverFlag")
							context.registerReceiver(receiver, filter);
						}
						
						// Track registered receiver for cleanup
						synchronized (registeredReceivers) {
							registeredReceivers.add(receiver);
						}

						usbManager.requestPermission(grantingDevice, permissionIntent);
					}
				}
				
				try {
					sleep(1000);
				} catch (InterruptedException e) {
                    // interrupted
				}
			}

            // the thread is finishing now.
            // notify detaches all devices
            for (UsbDevice device : grantedDevices) {
                // call the method immediately
                onDeviceDetached(device);
            }
            grantedDevices.clear();
		}

		/**
		 * checks Attached/Detached devices
		 */
	synchronized void checkConnectedDevices() {
		HashMap<String, UsbDevice> deviceMap = usbManager.getDeviceList();
		if (deviceMap == null) {
			deviceMap = new HashMap<>();
		}
			
			// check attached device
			for (UsbDevice device : deviceMap.values()) {
                if (deviceGrantQueue.contains(device) || connectedDevices.contains(device)) {
                    continue;
                }

                Set<UsbInterface> midiInterfaces = UsbMidiDeviceUtils.findAllMidiInterfaces(device, deviceFilters);
                if (midiInterfaces.size() > 0) {
                    Log.d(TAG, "attached deviceName:" + device.getDeviceName() + ", device:" + device);
                    synchronized (deviceGrantQueue) {
                        deviceGrantQueue.add(device);
                    }
                }
			}
			
			// check detached device
			for (UsbDevice device : connectedDevices) {
				if (!deviceMap.containsValue(device)) {
                    if (device.equals(grantingDevice)) {
                        // currently granting, but detached
                        grantingDevice = null;
                        continue;
                    }

                    grantedDevices.remove(device);

					Log.d(TAG, "detached deviceName:" + device.getDeviceName() + ", device:" + device);
                    deviceDetachedHandler.post(() -> {
                        onDeviceDetached(device);
                    });
				}
			}

            // update current connection status
			connectedDevices.clear();
            connectedDevices.addAll(deviceMap.values());
		}
	}
}
